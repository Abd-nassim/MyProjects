<?php
session_start();
if(!isset($_SESSION['nom']) ){  header("location:index.php");}


 include("nav.html"); 
?>
<style type="text/css">
	
	body {
    background-color:#202020;
}

</style>

<!DOCTYPE html>
<html>
<body>
	
			
	



   


</body>
</html>




 